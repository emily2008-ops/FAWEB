const express = require('express');
const bcrypt = require('bcryptjs');
const { ObjectId } = require('mongodb');
const { getDb } = require('../db');

const router = express.Router();

// REGISTRAR USUARIO
router.post('/registro', async (req, res) => {
    try {
        const { nombre, correo, password } = req.body;

        if (!nombre || !correo || !password) {
            return res.status(400).json({
                mensaje: 'Completa todos los campos'
            });
        }

        if (password.length < 8) {
            return res.status(400).json({
                mensaje: 'La contraseña debe tener mínimo 8 caracteres'
            });
        }

        const db = getDb();
        const correoNormalizado = correo.trim().toLowerCase();

        const existe = await db.collection('usuarios').findOne({
            correo: correoNormalizado
        });

        if (existe) {
            return res.status(409).json({
                mensaje: 'El correo ya está registrado'
            });
        }

        const passwordHash = await bcrypt.hash(password, 10);

        await db.collection('usuarios').insertOne({
            nombre: nombre.trim(),
            correo: correoNormalizado,
            passwordHash,
            rol: 'usuario',
            estado: true,
            fechaRegistro: new Date()
        });

        res.status(201).json({
            success: true,
            mensaje: 'Usuario registrado correctamente'
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            mensaje: 'Error al registrar usuario'
        });
    }
});


// CREAR USUARIO DESDE EL PANEL DE ADMINISTRACIÓN
// (igual que /registro, pero permite elegir rol y estado)
router.post('/usuarios', async (req, res) => {
    try {
        const { nombre, correo, password, rol, estado } = req.body;

        if (!nombre || !correo || !password) {
            return res.status(400).json({
                mensaje: 'Nombre, correo y contraseña son obligatorios'
            });
        }

        if (password.length < 8) {
            return res.status(400).json({
                mensaje: 'La contraseña debe tener mínimo 8 caracteres'
            });
        }

        const db = getDb();
        const correoNormalizado = correo.trim().toLowerCase();

        const existe = await db.collection('usuarios').findOne({
            correo: correoNormalizado
        });

        if (existe) {
            return res.status(409).json({
                mensaje: 'El correo ya está registrado'
            });
        }

        const passwordHash = await bcrypt.hash(password, 10);

        const resultado = await db.collection('usuarios').insertOne({
            nombre: nombre.trim(),
            correo: correoNormalizado,
            passwordHash,
            rol: rol === 'admin' ? 'admin' : 'usuario',
            estado: estado !== false, // true por defecto
            fechaRegistro: new Date()
        });

        res.status(201).json({
            success: true,
            mensaje: 'Usuario creado correctamente',
            _id: resultado.insertedId
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            mensaje: 'Error al crear usuario'
        });
    }
});


// CONSULTAR TODOS LOS USUARIOS
router.get('/usuarios', async (req, res) => {
    try {
        const db = getDb();

        const usuarios = await db.collection('usuarios')
            .find({})
            .project({ passwordHash: 0 })
            .toArray();

        res.json(usuarios);

    } catch (error) {
        console.error(error);
        res.status(500).json({
            mensaje: 'Error al consultar usuarios'
        });
    }
});


// CONSULTAR UN USUARIO
router.get('/usuarios/:id', async (req, res) => {
    try {
        const { id } = req.params;

        if (!ObjectId.isValid(id)) {
            return res.status(400).json({
                mensaje: 'ID de usuario inválido'
            });
        }

        const db = getDb();

        const usuario = await db.collection('usuarios').findOne(
            { _id: new ObjectId(id) },
            { projection: { passwordHash: 0 } }
        );

        if (!usuario) {
            return res.status(404).json({
                mensaje: 'Usuario no encontrado'
            });
        }

        res.json(usuario);

    } catch (error) {
        console.error(error);
        res.status(500).json({
            mensaje: 'Error al consultar usuario'
        });
    }
});


// ACTUALIZAR USUARIO
router.put('/usuarios/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { nombre, correo, password, rol, estado } = req.body;

        if (!ObjectId.isValid(id)) {
            return res.status(400).json({
                mensaje: 'ID de usuario inválido'
            });
        }

        if (!nombre || !correo) {
            return res.status(400).json({
                mensaje: 'Nombre y correo son obligatorios'
            });
        }

        const db = getDb();
        const coleccion = db.collection('usuarios');

        const correoNormalizado = correo.trim().toLowerCase();

        const existe = await coleccion.findOne({
            correo: correoNormalizado,
            _id: { $ne: new ObjectId(id) }
        });

        if (existe) {
            return res.status(409).json({
                mensaje: 'El correo ya pertenece a otro usuario'
            });
        }

        const datosActualizar = {
            nombre: nombre.trim(),
            correo: correoNormalizado
        };

        // Rol y estado solo se cambian si vienen en la petición
        if (rol === 'admin' || rol === 'usuario') {
            datosActualizar.rol = rol;
        }

        if (typeof estado === 'boolean') {
            datosActualizar.estado = estado;
        }

        if (password) {
            if (password.length < 8) {
                return res.status(400).json({
                    mensaje: 'La contraseña debe tener mínimo 8 caracteres'
                });
            }

            datosActualizar.passwordHash = await bcrypt.hash(password, 10);
        }

        const resultado = await coleccion.updateOne(
            { _id: new ObjectId(id) },
            { $set: datosActualizar }
        );

        if (resultado.matchedCount === 0) {
            return res.status(404).json({
                mensaje: 'Usuario no encontrado'
            });
        }

        res.json({
            success: true,
            mensaje: 'Usuario actualizado correctamente'
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            mensaje: 'Error al actualizar usuario'
        });
    }
});


// ELIMINAR USUARIO (DESACTIVAR)
router.delete('/usuarios/:id', async (req, res) => {
    try {
        const { id } = req.params;

        if (!ObjectId.isValid(id)) {
            return res.status(400).json({
                mensaje: 'ID de usuario inválido'
            });
        }

        const db = getDb();

        const resultado = await db.collection('usuarios').updateOne(
            { _id: new ObjectId(id) },
            { $set: { estado: false } }
        );

        if (resultado.matchedCount === 0) {
            return res.status(404).json({
                mensaje: 'Usuario no encontrado'
            });
        }

        res.json({
            success: true,
            mensaje: 'Usuario desactivado correctamente'
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            mensaje: 'Error al eliminar usuario'
        });
    }
});

module.exports = router;