const express = require('express');
const router = express.Router();

const { getDb, ObjectId } = require('../db');

const COLECCION = 'productos';


// ==============================================
// FUNCIONES DE AYUDA
// ==============================================

// Limpia y convierte los datos que llegan del panel
function armarProducto(body) {
    const texto = valor => (typeof valor === 'string' ? valor.trim() : '');
    const siNo = valor => valor === true || valor === 'true';

    return {
        codigo: texto(body.codigo).toUpperCase(),
        numero: texto(body.numero),
        nombre: texto(body.nombre),
        precio: Number(body.precio),
        exclusivo: siNo(body.exclusivo),
        resumen: texto(body.resumen),
        descripcion: texto(body.descripcion),
        caracteristicas: Array.isArray(body.caracteristicas)
            ? body.caracteristicas.map(texto).filter(Boolean)
            : [],
        idealPara: texto(body.idealPara),
        envio: texto(body.envio),
        garantia: texto(body.garantia),
        imagen: texto(body.imagen),
        imagenTarjeta: texto(body.imagenTarjeta) || texto(body.imagen),
        activo: body.activo === undefined ? true : siNo(body.activo)
    };
}

// Revisa que lo obligatorio esté bien
function validarProducto(producto) {
    if (!producto.nombre) return 'El nombre es obligatorio';
    if (!Number.isFinite(producto.precio) || producto.precio < 0) return 'El precio no es válido';
    return null;
}

// Genera el siguiente código: FW-00001, FW-00002, ...
async function siguienteCodigo(coleccion) {
    let numero = (await coleccion.countDocuments()) + 1;
    let codigo;

    do {
        codigo = 'FW-' + String(numero).padStart(5, '0');
        numero++;
    } while (await coleccion.findOne({ codigo }));

    return codigo;
}


// ==============================================
// VER TODOS LOS PRODUCTOS
// GET /producto
// ==============================================
router.get('/producto', async (req, res) => {
    try {
        const productos = await getDb()
            .collection(COLECCION)
            .find()
            .sort({ fechaCreacion: -1 }) // los más recientes primero
            .toArray();

        res.status(200).json(productos);

    } catch (error) {
        console.error(error);
        res.status(500).json({ mensaje: 'Error al obtener los productos' });
    }
});


// ==============================================
// VER UN PRODUCTO
// GET /producto/:id   (lo usa productos.html?id=...)
// ==============================================
router.get('/producto/:id', async (req, res) => {
    try {
        const { id } = req.params;

        if (!ObjectId.isValid(id)) {
            return res.status(400).json({ mensaje: 'ID no válido' });
        }

        const producto = await getDb()
            .collection(COLECCION)
            .findOne({ _id: new ObjectId(id) });

        if (!producto) {
            return res.status(404).json({ mensaje: 'Producto no encontrado' });
        }

        res.status(200).json(producto);

    } catch (error) {
        console.error(error);
        res.status(500).json({ mensaje: 'Error al obtener el producto' });
    }
});


// ==============================================
// CREAR PRODUCTO
// POST /producto
// ==============================================
router.post('/producto', async (req, res) => {
    try {
        const producto = armarProducto(req.body);
        const error = validarProducto(producto);

        if (error) {
            return res.status(400).json({ mensaje: error });
        }

        const coleccion = getDb().collection(COLECCION);

        if (!producto.codigo) {
            producto.codigo = await siguienteCodigo(coleccion);
        } else if (await coleccion.findOne({ codigo: producto.codigo })) {
            return res.status(409).json({ mensaje: 'Ya existe un producto con ese código' });
        }

        producto.fechaCreacion = new Date();

        const resultado = await coleccion.insertOne(producto);

        res.status(201).json({
            mensaje: 'Producto creado correctamente',
            _id: resultado.insertedId,
            codigo: producto.codigo
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ mensaje: 'Error al crear el producto' });
    }
});


// ==============================================
// ACTUALIZAR PRODUCTO
// PUT /producto/:id
// ==============================================
router.put('/producto/:id', async (req, res) => {
    try {
        const { id } = req.params;

        if (!ObjectId.isValid(id)) {
            return res.status(400).json({ mensaje: 'ID no válido' });
        }

        const producto = armarProducto(req.body);
        const error = validarProducto(producto);

        if (error) {
            return res.status(400).json({ mensaje: error });
        }

        const coleccion = getDb().collection(COLECCION);

        if (producto.codigo) {
            const repetido = await coleccion.findOne({
                codigo: producto.codigo,
                _id: { $ne: new ObjectId(id) }
            });

            if (repetido) {
                return res.status(409).json({ mensaje: 'Ese código ya lo usa otro producto' });
            }
        } else {
            delete producto.codigo; // si se deja vacío, se conserva el que tenía
        }

        producto.fechaActualizacion = new Date();

        const resultado = await coleccion.updateOne(
            { _id: new ObjectId(id) },
            { $set: producto }
        );

        if (resultado.matchedCount === 0) {
            return res.status(404).json({ mensaje: 'Producto no encontrado' });
        }

        res.status(200).json({ mensaje: 'Producto actualizado correctamente' });

    } catch (error) {
        console.error(error);
        res.status(500).json({ mensaje: 'Error al actualizar el producto' });
    }
});


// ==============================================
// ELIMINAR PRODUCTO
// DELETE /producto/:id
// ==============================================
router.delete('/producto/:id', async (req, res) => {
    try {
        const { id } = req.params;

        if (!ObjectId.isValid(id)) {
            return res.status(400).json({ mensaje: 'ID no válido' });
        }

        const resultado = await getDb()
            .collection(COLECCION)
            .deleteOne({ _id: new ObjectId(id) });

        if (resultado.deletedCount === 0) {
            return res.status(404).json({ mensaje: 'Producto no encontrado' });
        }

        res.status(200).json({ mensaje: 'Producto eliminado correctamente' });

    } catch (error) {
        console.error(error);
        res.status(500).json({ mensaje: 'Error al eliminar el producto' });
    }
});


module.exports = router;