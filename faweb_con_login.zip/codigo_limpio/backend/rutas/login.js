const express = require('express');
const bcrypt = require('bcryptjs');
const { getDb } = require('../db');

const router = express.Router();

router.post('/', async (req, res) => {
    try {
        const { correo, password } = req.body;

        if (!correo || !password) {
            return res.status(400).json({
                mensaje: 'Completa todos los campos'
            });
        }

        const db = getDb();

        const usuario = await db.collection('usuarios').findOne({
            correo: correo.trim().toLowerCase()
        });

        if (!usuario || !await bcrypt.compare(password, usuario.passwordHash)) {
            return res.status(401).json({
                mensaje: 'Correo o contraseña incorrectos'
            });
        }

        if (usuario.estado === false) {
            return res.status(403).json({
                mensaje: 'Usuario desactivado'
            });
        }

        if (!['admin', 'usuario'].includes(usuario.rol)) {
            return res.status(403).json({
                mensaje: 'Rol no válido'
            });
        }

        req.session.regenerate((error) => {
            if (error) {
                return res.status(500).json({
                    mensaje: 'Error iniciando sesión'
                });
            }

            req.session.usuario = {
                id: usuario._id.toString(),
                nombre: usuario.nombre,
                correo: usuario.correo,
                rol: usuario.rol
            };

            req.session.save((error) => {
                if (error) {
                    return res.status(500).json({
                        mensaje: 'Error guardando sesión'
                    });
                }

                res.json({
                    success: true,
                    mensaje: 'Bienvenido',
                    rol: usuario.rol
                });
            });
        });

    } catch (error) {
        console.error(error);

        res.status(500).json({
            mensaje: 'Error en el inicio de sesión'
        });
    }
});

router.get('/verificar', (req, res) => {
    if (!req.session.usuario) {
        return res.status(401).json({
            success: false,
            mensaje: 'No has iniciado sesión'
        });
    }

    res.json({
        success: true,
        usuario: req.session.usuario
    });
});

router.post('/logout', (req, res) => {
    req.session.destroy((error) => {
        if (error) {
            return res.status(500).json({
                mensaje: 'Error cerrando sesión'
            });
        }

        res.clearCookie('faweb.sid');

        res.json({
            success: true,
            mensaje: 'Sesión cerrada'
        });
    });
});

module.exports = router;