const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {

    if (!req.session.usuario) {
        return res.status(401).json({
            mensaje: 'Debes iniciar sesión'
        });
    }

    if (req.session.usuario.rol !== 'admin') {
        return res.status(403).json({
            mensaje: 'No tienes permisos de administrador'
        });
    }

    res.json({
        success: true,
        mensaje: 'Acceso administrativo autorizado',
        usuario: req.session.usuario
    });

});

module.exports = router;